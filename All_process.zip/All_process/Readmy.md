to launch a project: 
You must be in the program directory. after that, write make in the console. 
This command will launch the program.

The console will record all the programs that run on your computer
to stop the process, enter its identifier in the console
to stop the program, write q