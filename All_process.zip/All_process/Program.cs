﻿using System;
using System.Diagnostics;
using System.Linq;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    PrintProcessList();

                    Console.Write("Enter process ID to kill or 'q' to exit: ");
                    string inputCommand = Console.ReadLine();

                    if (inputCommand.ToLower() == "q")
                    {
                        break;
                    }

                    if (int.TryParse(inputCommand, out int processId))
                    {
                        KillProcessById(processId);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input. Please enter a valid process ID or 'q' to exit.");
                        Console.ResetColor();
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Error: {ex.Message}");
                    Console.ResetColor();
                }
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Press F to pay respects");
                Console.ResetColor();
                Console.ReadKey();
            }
        }

        static void PrintProcessList()
        {
            Process[] processList = Process.GetProcesses();

            Console.WriteLine("ID\tName");
            Console.WriteLine("--\t----");

            foreach (Process process in processList)
            {
                Console.WriteLine($"{process.Id}\t{process.ProcessName}");
            }
        }

        static void KillProcessById(int processId)
        {
            Process process = Process.GetProcesses().FirstOrDefault(p => p.Id == processId);

            if (process != null)
            {
                try
                {
                    process.Kill();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Process '{process.ProcessName}' (ID: {process.Id}) has been killed.");
                    Console.ResetColor();
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Error killing process: {ex.Message}");
                    Console.ResetColor();
                    
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Process with ID {processId} not found.");
                Console.ResetColor();
            }
        }
    }
}
